---
title: "Welcome To My Blog"
date: "2020-11-02 02:12:52 +0200"
author: NrdyBhu1
category: blog 
---

Hey! After many months of time pass, I have been finally able to create a blogging website with jekyll theme.
This is my first post. There may be many changes to this website in futures.
Thank you.

To add new posts, simply add a file in the _posts directory that follows the convention YYYY-MM-DD-name-of-post.ext and includes the necessary front matter. Take a look at the source for this post to get an idea about how it works.

Jekyll also offers powerful support for code snippets:

{% highlight ruby %}
def print_hi(name) 
    puts "Hi, #{name}" 
    end print_hi('Tom') 
    #=> prints 'Hi, Tom' to STDOUT. 
{% endhighlight %}

Check out the Jekyll docs for more info on how to get the most out of Jekyll. File all bugs/feature requests at Jekyll’s GitHub repo. If you have questions, you can ask them on Jekyll Talk.
