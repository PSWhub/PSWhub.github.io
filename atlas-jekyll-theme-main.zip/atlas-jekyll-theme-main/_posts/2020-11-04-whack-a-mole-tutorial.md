---
title: "Whack A Mole Tutorial"
date: "2020-11-04 03:32:00 +0200"
author: NrdyBhu1
category: blog 
---

{: .note .info}
This is not a tutorial

View the entire tutorial on [youtube](https://www.youtube.com/playlist?list=PLRaOHS3cZ5NvarY2OpFhzBl5aoGQF_8Ub)

<a href="{{ '/zips/whack-mole-assets.zip' | relative_url }}"><button>Download Assets <i class="fas fa-download"></i></button></a> \
<a href="https://github.com/NrdyBhu1/Mouse-Cursor-Follow/archive/master.zip"><button>Download project files <i class="fas fa-download"></i></button></a> 