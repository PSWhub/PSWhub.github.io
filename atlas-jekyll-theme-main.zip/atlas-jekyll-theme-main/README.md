# Atlas-jekyll-theme
![Preview](./atlas-normal.png)

## How to use
  - Delete the markdown files from \_posts and add your blog posts in the folder
  - Change the details in \_config.yml
