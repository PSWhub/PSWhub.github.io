---
permalink: /mail.html
redirect_to: 'mailto: nrdybhu1.queries@gmail.com'
---