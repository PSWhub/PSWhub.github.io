---
permalink: /patreon.html
redirect_to: https://patreon.com/NrdyBhu1
---