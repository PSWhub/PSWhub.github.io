---
permalink: /youtube.html
redirect_to: https://www.youtube.com/channel/UCoPBq4YveNbsHkg4Rd9AXXQ
---