---
permalink: /issues.html
redirect_to: https://github.com/NrdyBhu1/atlas-jekyll-theme/issues
---