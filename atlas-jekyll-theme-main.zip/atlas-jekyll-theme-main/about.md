---
layout: post
title: About Me
permalink: /about/
redirect_from: /about.html
---

## Hi there 👋
Introduce your self
I`m NrdyBhu1

# About Me
Tell more about your self
I am a passionate game dev 👨🏻‍💻 and i learnt many languages only to make games.

Talk about your projects
# My first project
My first project was a prototype which was unfinished but still it was a game.

Link your social accounts
# Social Accounts
[Itch.io](#) \
[Patreon](#) \
[Youtube](#) \
[My Website](#) \
[Gmail](#) \
[Github](#)

Show your github Stats
# Stats
<p>
    <img src="https://github-readme-stats.vercel.app/api?username=NrdyBhu1&show_icons=true&layout=compact&bg_color=30,12c2e9,f64f59&title_color=fff&text_color=fff">
    <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=NrdyBhu1&layout=compact&bg_color=30,1565C0,b92b27&title_color=fff&text_color=fff">
</p>

Your showcase here
# My Showcase
<p>
    <a href="https://github.com/Jekyll/jekyll"> <img src="https://github-readme-stats.vercel.app/api/pin/?username=Jekyll&repo=jekyll&show_owner=true&bg_color=30,e96443,904e95&title_color=fff&text_color=fff"></a>
    <a href="https://github.com/Jekyll/teams"> <img src="https://github-readme-stats.vercel.app/api/pin/?username=Jekyll&repo=teams&show_owner=true&bg_color=30,e96443,904e95&title_color=fff&text_color=fff"></a>
</p>

